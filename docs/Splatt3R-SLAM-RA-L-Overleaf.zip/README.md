# Splatt3R-SLAM RA-L Overleaf package

Upload this ZIP as a new Overleaf project. The root `main.tex` builds the
anonymous RA-L review manuscript. If Overleaf does not select the settings
automatically, choose:

- Main document: `main.tex`
- Compiler: `pdfLaTeX`

`ral.tex` is the authored IEEEtran reading version. All included figure PDFs
are compatible with pdfTeX PDF 1.5.
